package com.university.shenyang.air.testing.pojo;

public class DeviceCodeMappingUsername {
    private String deviceCode;

    private String userName;

    public String getDeviceCode() {
        return deviceCode;
    }

    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}