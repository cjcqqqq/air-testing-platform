package com.university.shenyang.air.testing.collector.util;


public class Constants {
    public final static String REPORT_REDIS_KEY_PREFIX = "REPORT_";
    public final static String LATEST_REPORT_REDIS_KEY_PREFIX = "LATEST_REPORT_";
}
