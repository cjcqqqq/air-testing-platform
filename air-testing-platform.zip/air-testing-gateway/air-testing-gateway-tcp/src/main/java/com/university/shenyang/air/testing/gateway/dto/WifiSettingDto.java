package com.university.shenyang.air.testing.gateway.dto;

/**
 * Created by cjcqqqq on 2017/5/17.
 */
public class WifiSettingDto extends BaseDto{

}
