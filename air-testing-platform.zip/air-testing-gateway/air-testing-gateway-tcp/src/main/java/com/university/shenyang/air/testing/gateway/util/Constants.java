package com.university.shenyang.air.testing.gateway.util;


public class Constants {
    public final static String PROTOCOL_GB = "GB";
    public final static int HEAD = 0x2323;

    public final static String REPORT_REDIS_KEY_PREFIX = "REPORT_";
    public final static String LATEST_REPORT_REDIS_KEY_PREFIX = "LATEST_REPORT_";
    public final static String PARAM_REDIS_KEY_PREFIX = "PARAM_";
}
