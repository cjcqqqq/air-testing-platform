package com.university.shenyang.air.testing.monitoring.command;

/**
 * Created by cjcqqqq on 2017/5/17.
 */
public class BaseCommand {

}
