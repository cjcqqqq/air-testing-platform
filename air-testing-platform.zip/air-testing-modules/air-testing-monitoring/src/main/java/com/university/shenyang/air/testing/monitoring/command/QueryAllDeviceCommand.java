package com.university.shenyang.air.testing.monitoring.command;

public class QueryAllDeviceCommand extends BaseCommand {
}
