package com.university.shenyang.air.testing.monitoring.command;

/**
 * Created by pbw on 2018/6/11.
 */
public class QueryAllHourInfoCommand extends BaseCommand{
}
