package com.university.shenyang.air.testing.monitoring.command;
import org.hibernate.validator.constraints.NotEmpty;
/**
 * Created by pbw on 2018/4/24.
 */
public class QueryAllLatestReportCommand extends BaseCommand {
}
