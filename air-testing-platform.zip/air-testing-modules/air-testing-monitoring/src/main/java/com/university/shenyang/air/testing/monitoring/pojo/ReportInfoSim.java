package com.university.shenyang.air.testing.monitoring.pojo;

public class ReportInfoSim {

    private Float lng;

    private Float lat;
    private String count;



    public Float getLng() {
        return lng;
    }

    public void setLng(Float lng) {
        this.lng = lng;
    }

    public Float getLat() {
        return lat;
    }

    public void setLat(Float lat) {
        this.lat = lat;
    }

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }
}