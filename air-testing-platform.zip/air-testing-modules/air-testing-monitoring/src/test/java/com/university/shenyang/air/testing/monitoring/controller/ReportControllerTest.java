package com.university.shenyang.air.testing.monitoring.controller;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by pbw on 2018/4/6.
 */
public class ReportControllerTest {
    @Test
    public void getLatestReport() throws Exception {

    }

}